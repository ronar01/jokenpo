import 'package:flutter/material.dart';
import 'package:jokenpo/Jogo.dart';

void main(){
  runApp(const MaterialApp(
      home: Jogo(),
      debugShowCheckedModeBanner: false,
  ));
}