package com.example.jokenpo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
